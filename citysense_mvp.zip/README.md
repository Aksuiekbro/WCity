# CitySense — NASA-data Urban Planning Copilot (Space Apps MVP)

This repo provides a minimal, reproducible pipeline and a Streamlit app.
It ships with **synthetic rasters** so it runs anywhere. Replace them with real NASA-derived datasets later.

## Demo quick start
1. `python -m venv .venv && source .venv/bin/activate`  (Windows: `.venv\Scripts\activate`)
2. `pip install -r requirements.txt`
3. `python scripts/00_make_synthetic_demo.py`
4. `python scripts/03_compute_indices.py`
5. `streamlit run streamlit_app.py`
