import numpy as np
from .indices import uhi_cooling_gap, air_quality_exposure, flood_susceptibility, green_equity, zscore

def apply_tree_planting(canopy, buffer_mask=None, pct_increase=10.0):
    factor = 1.0 + pct_increase/100.0
    out = canopy.copy()
    if buffer_mask is None:
        out = out * factor
    else:
        out = out * (1 - buffer_mask) + (out * factor) * buffer_mask
    return out

def apply_cool_roofs(lst, roof_fraction=0.1, delta_c=-1.0):
    out = lst.copy()
    out = out + delta_c * roof_fraction
    return out

def apply_bus_electrification(no2, corridor_mask=None, reduction_pct=20.0):
    factor = 1.0 - reduction_pct/100.0
    out = no2.copy()
    if corridor_mask is None:
        out = out * factor
    else:
        out = out * (1 - corridor_mask) + (out * factor) * corridor_mask
    return out

def apply_drainage_upgrade(fsi, reduction_pct=15.0):
    return fsi * (1.0 - reduction_pct/100.0)
