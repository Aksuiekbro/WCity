import numpy as np

def zscore(x):
    m = np.nanmean(x)
    s = np.nanstd(x)
    if s == 0 or np.isnan(s):
        return np.zeros_like(x, dtype=float)
    return (x - m) / s

def uhi_cooling_gap(lst, pop, canopy):
    return zscore(lst) + zscore(pop) - zscore(canopy)

def flood_susceptibility(rain_max24h, flow_accum, soil_wet, w=(0.4, 0.3, 0.3)):
    a, b, c = w
    return a*zscore(rain_max24h) + b*zscore(flow_accum) + c*zscore(soil_wet)

def air_quality_exposure(no2, aod):
    return zscore(no2) + zscore(aod)

def green_equity(pop, canopy, ndvi=None):
    term = zscore(canopy)
    if ndvi is not None:
        term = 0.5*(zscore(canopy) + zscore(ndvi))
    return zscore(pop) - term
