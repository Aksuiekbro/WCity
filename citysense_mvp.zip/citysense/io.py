from pathlib import Path
import rasterio
from rasterio.enums import Resampling
import rasterio.warp
import numpy as np

def read_raster(path):
    path = Path(path)
    ds = rasterio.open(path)
    arr = ds.read(1, masked=True)
    return arr, ds

def write_raster_like(ref_ds, array, out_path, dtype=None, nodata=None, compress='deflate'):
    profile = ref_ds.profile.copy()
    profile.update(count=1, compress=compress)
    if dtype: profile.update(dtype=dtype)
    if nodata is not None: profile.update(nodata=nodata)
    out_path = Path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with rasterio.open(out_path, 'w', **profile) as dst:
        dst.write(array, 1)
    return out_path

def resample_to_match(src_arr, src_ds, ref_ds, resampling=Resampling.bilinear):
    out = np.empty((ref_ds.height, ref_ds.width), dtype=np.float32)
    rasterio.warp.reproject(
        src_arr, out,
        src_transform=src_ds.transform, src_crs=src_ds.crs,
        dst_transform=ref_ds.transform, dst_crs=ref_ds.crs,
        dst_nodata=np.nan,
        resampling=resampling
    )
    return np.ma.masked_invalid(out)
