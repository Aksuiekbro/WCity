import streamlit as st
from pathlib import Path
import numpy as np
from PIL import Image
from citysense.io import read_raster
from citysense.scenarios import apply_tree_planting, apply_cool_roofs, apply_bus_electrification, apply_drainage_upgrade
from citysense.indices import uhi_cooling_gap, flood_susceptibility, air_quality_exposure, green_equity

st.set_page_config(page_title='CitySense', layout='wide')
st.title('CitySense — NASA-data Urban Planning Copilot (MVP)')
st.markdown('This demo uses synthetic rasters so it runs anywhere. Swap them with real datasets in data/rasters and recompute.')

base_dir = Path('data/rasters')
lst, ref = read_raster(base_dir/'heat_lst.tif')
rain, _ = read_raster(base_dir/'rain_max24h.tif')
flow, _ = read_raster(base_dir/'flow_accum.tif')
soil, _ = read_raster(base_dir/'soil_wetness.tif')
no2, _  = read_raster(base_dir/'no2_column.tif')
aod, _  = read_raster(base_dir/'aod.tif')
canopy, _ = read_raster(base_dir/'canopy_height.tif')
pop, _ = read_raster(base_dir/'population.tif')

st.sidebar.header('Layers & Scenarios')
layer = st.sidebar.selectbox('Layer', ['UHI (Cooling Gap)', 'FSI (Flood)', 'AQE (Air Quality)', 'GEI (Green Equity)'])
tree_pct = st.sidebar.slider('Tree planting: canopy increase (%)', 0.0, 50.0, 0.0, 1.0)
roof_frac = st.sidebar.slider('Cool roofs: roof coverage fraction', 0.0, 0.8, 0.0, 0.05)
roof_delta = st.sidebar.slider('Cool roof LST reduction (°C)', -5.0, 0.0, -1.0, 0.1)
bus_red = st.sidebar.slider('Bus electrification: NO₂ reduction (%)', 0.0, 50.0, 0.0, 1.0)
drain_red = st.sidebar.slider('Drainage upgrades: FSI reduction (%)', 0.0, 50.0, 0.0, 1.0)

lst_s = apply_cool_roofs(lst, roof_fraction=roof_frac, delta_c=roof_delta)
canopy_s = apply_tree_planting(canopy, pct_increase=tree_pct)
no2_s = apply_bus_electrification(no2, reduction_pct=bus_red)

uhi = uhi_cooling_gap(lst_s, pop, canopy_s)
fsi = flood_susceptibility(rain, flow, soil)
fsi = apply_drainage_upgrade(fsi, reduction_pct=drain_red)
aqe = air_quality_exposure(no2_s, aod)
gei = green_equity(pop, canopy_s)

def arr_to_img(a):
    arr = a.filled(np.nan)
    m = np.nanpercentile(arr, 2)
    M = np.nanpercentile(arr, 98)
    if M - m < 1e-6:
        M = m + 1e-6
    norm = np.clip((arr - m)/(M - m), 0, 1)
    img = (norm*255).astype('uint8')
    return Image.fromarray(img)

col1, col2 = st.columns([3,1])
with col1:
    if layer == 'UHI (Cooling Gap)':
        st.subheader('UHI — Cooling Gap Index')
        st.image(arr_to_img(uhi), use_column_width=True, caption='Higher = hotter + more people + less canopy')
    elif layer == 'FSI (Flood)':
        st.subheader('FSI — Flood Susceptibility Index')
        st.image(arr_to_img(fsi), use_column_width=True, caption='Higher = more prone to pluvial flooding')
    elif layer == 'AQE (Air Quality)':
        st.subheader('AQE — Air-Quality Exposure')
        st.image(arr_to_img(aqe), use_column_width=True, caption='Higher = higher NO₂ + AOD')
    else:
        st.subheader('GEI — Green Equity Index')
        st.image(arr_to_img(gei), use_column_width=True, caption='Higher = more people but less canopy/NDVI')

with col2:
    def pct_change(baseline, scenario):
        b = np.nanmean(baseline)
        s = np.nanmean(scenario)
        if abs(b) < 1e-9:
            return 0.0
        return 100.0 * (s - b) / abs(b)
    uhi_b = uhi_cooling_gap(lst, pop, canopy)
    aqe_b = air_quality_exposure(no2, aod)
    gei_b = green_equity(pop, canopy)
    fsi_b = flood_susceptibility(rain, flow, soil)
    st.write(f'UHI mean change: {pct_change(uhi_b, uhi):+.2f}%')
    st.write(f'AQE mean change: {pct_change(aqe_b, aqe):+.2f}%')
    st.write(f'FSI mean change: {pct_change(fsi_b, fsi):+.2f}%')
    st.write(f'GEI mean change: {pct_change(gei_b, gei):+.2f}%')
