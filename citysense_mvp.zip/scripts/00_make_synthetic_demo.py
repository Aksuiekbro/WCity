from pathlib import Path
import numpy as np
import rasterio
from rasterio.transform import from_origin

w = 200; h = 200; res = 30
transform = from_origin(0, 0, res, res)
crs = 'EPSG:3857'

def save(path, arr, nodata=np.nan, dtype='float32'):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    profile = {'driver':'GTiff','height':arr.shape[0],'width':arr.shape[1],'count':1,
               'dtype':dtype,'crs':crs,'transform':transform,'nodata':nodata,'compress':'deflate'}
    with rasterio.open(path,'w',**profile) as dst:
        dst.write(arr.astype(dtype),1)

def radial_gradient(cx, cy):
    y, x = np.indices((h,w))
    r = np.sqrt((x-cx)**2 + (y-cy)**2)
    return (r - r.min())/(r.max()-r.min() + 1e-6)

if __name__ == '__main__':
    out = Path('data/rasters')
    lst = 35 - 7*radial_gradient(90, 100) + np.random.normal(0,0.3,(h,w))
    save(out/'heat_lst.tif', lst)
    rain = 40 + 60*radial_gradient(10, 20) + np.random.normal(0,1,(h,w))
    save(out/'rain_max24h.tif', rain)
    flow = np.zeros((h,w), dtype=float)
    flow[:, 95:105] = 100
    flow[120:140, :] += 50
    flow += np.random.rand(h,w)*3
    save(out/'flow_accum.tif', flow)
    soil = np.clip(np.random.normal(0.5, 0.15, (h,w)), 0, 1)
    save(out/'soil_wetness.tif', soil)
    no2 = 1e-4*np.ones((h,w))
    no2[:, 98:102] += 2e-4
    save(out/'no2_column.tif', no2)
    aod = np.clip(0.2 + 0.25*radial_gradient(180, 10) + np.random.normal(0,0.02,(h,w)), 0.01, 0.8)
    save(out/'aod.tif', aod)
    canopy = np.clip(12*radial_gradient(100, 100), 0, 25)
    save(out/'canopy_height.tif', canopy)
    pop = 50 + 250*(1 - radial_gradient(100, 100))
    save(out/'population.tif', pop)
