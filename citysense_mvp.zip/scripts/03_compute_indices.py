import sys, pathlib
sys.path.append(str(pathlib.Path(__file__).resolve().parents[1]))
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
from citysense.io import read_raster, write_raster_like
from citysense.indices import uhi_cooling_gap, flood_susceptibility, air_quality_exposure, green_equity

def save_png(arr, out_png, cmap='viridis'):
    import matplotlib.pyplot as plt
    plt.figure()
    plt.imshow(arr, cmap=cmap)
    plt.axis('off')
    Path(out_png).parent.mkdir(parents=True, exist_ok=True)
    plt.savefig(out_png, bbox_inches='tight', pad_inches=0)
    plt.close()

if __name__ == '__main__':
    base = Path('data/rasters')
    outd = Path('data/indices')
    lst, ref = read_raster(base/'heat_lst.tif')
    rain, _ = read_raster(base/'rain_max24h.tif')
    flow, _ = read_raster(base/'flow_accum.tif')
    soil, _ = read_raster(base/'soil_wetness.tif')
    no2, _  = read_raster(base/'no2_column.tif')
    aod, _  = read_raster(base/'aod.tif')
    canopy, _ = read_raster(base/'canopy_height.tif')
    pop, _ = read_raster(base/'population.tif')
    uhi = uhi_cooling_gap(lst, pop, canopy)
    fsi = flood_susceptibility(rain, flow, soil)
    aqe = air_quality_exposure(no2, aod)
    gei = green_equity(pop, canopy)
    write_raster_like(ref, uhi.filled(np.nan), outd/'UHI_cooling_gap.tif', dtype='float32', nodata=np.nan)
    write_raster_like(ref, fsi.filled(np.nan), outd/'FSI.tif', dtype='float32', nodata=np.nan)
    write_raster_like(ref, aqe.filled(np.nan), outd/'AQE.tif', dtype='float32', nodata=np.nan)
    write_raster_like(ref, gei.filled(np.nan), outd/'GEI.tif', dtype='float32', nodata=np.nan)
    save_png(uhi, outd/'UHI_cooling_gap.png')
    save_png(fsi, outd/'FSI.png')
    save_png(aqe, outd/'AQE.png')
    save_png(gei, outd/'GEI.png')
    print('Indices computed: UHI, FSI, AQE, GEI. Outputs in data/indices/.')
